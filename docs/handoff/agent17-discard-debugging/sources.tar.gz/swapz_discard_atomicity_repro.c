// Standalone extraction of DM swapz_discard() as inspected at 2c1b0ab...
// The stub swapz_discard_page() models its production mapped-count rejection.
#include <assert.h>
#include <stdbool.h>
#include <stdint.h>
#include <errno.h>
#include <stdio.h>
#include <string.h>
typedef uint64_t sector_t;
typedef uint32_t swapz_u32;
#define SWAPZ_SECTORS 8U
#define SWAPZ_SEGMENT_BLOCKS 256U
#define PHYSICAL_BLOCKS 512U
struct swapz_map { swapz_u32 start_block, generation; unsigned extent_blocks, valid; };
struct swapz_dm;
struct swapz_authority { swapz_u32 open_segment; struct swapz_dm *ctx; };
struct swapz_dm {
    swapz_u32 logical_pages, physical_blocks;
    struct swapz_map *maps;
    uint8_t *extent_classes;
    uint16_t *live_records;
    swapz_u32 *segment_mapped_pages;
    struct swapz_authority authority;
    unsigned discard_pages;
};
struct bio { struct { sector_t bi_sector; } bi_iter; sector_t sectors; };
static sector_t bio_sectors(struct bio *bio) { return bio->sectors; }
static int swapz_discard_page(struct swapz_authority *authority, swapz_u32 logical) {
    struct swapz_dm *ctx = authority->ctx;
    struct swapz_map *old = &ctx->maps[logical];
    swapz_u32 old_segment = old->start_block / SWAPZ_SEGMENT_BLOCKS;
    // Same production sidecar failure, encountered only on second page.
    if (old->valid && !ctx->segment_mapped_pages[old_segment]) return -EUCLEAN;
    if (old->valid) {
        --ctx->live_records[old->start_block];
        --ctx->segment_mapped_pages[old_segment];
    }
    memset(old, 0, sizeof(*old));
    old->generation = 2U;
    return 0;
}
static int swapz_discard_dead_segment(struct swapz_dm *ctx, swapz_u32 segment) {
    (void)ctx; (void)segment; return 0;
}
static bool swapz_map_extent_bounds_valid(const struct swapz_dm *ctx,
                                          const struct swapz_map *map) {
    return map->start_block < ctx->physical_blocks &&
        (map->extent_blocks == 1U || map->extent_blocks == 2U || map->extent_blocks == 4U) &&
        map->extent_blocks <= ctx->physical_blocks - map->start_block &&
        map->start_block % SWAPZ_SEGMENT_BLOCKS + map->extent_blocks <= SWAPZ_SEGMENT_BLOCKS;
}
static int swapz_discard(struct swapz_dm *ctx, struct bio *bio)
{
    sector_t sector = bio->bi_iter.bi_sector;
    sector_t remaining = bio_sectors(bio);
    int error;
    if (sector % SWAPZ_SECTORS || remaining % SWAPZ_SECTORS ||
        sector / SWAPZ_SECTORS >= ctx->logical_pages ||
        remaining / SWAPZ_SECTORS >
            ctx->logical_pages - sector / SWAPZ_SECTORS)
        return -ERANGE;
    {
        sector_t check_sector = sector;
        sector_t check_remaining = remaining;
        sector_t restore_sector;
        int check_error = 0;
        while (check_remaining) {
            swapz_u32 logical = (swapz_u32)(check_sector / SWAPZ_SECTORS);
            const struct swapz_map *m = &ctx->maps[logical];
            if (m->generation == ~(swapz_u32)0) {
                check_error = -EOVERFLOW;
                break;
            }
            if (m->valid) {
                swapz_u32 start = m->start_block;
                if (!swapz_map_extent_bounds_valid(ctx, m) ||
                    ctx->extent_classes[start] != m->extent_blocks ||
                    !ctx->live_records[start]) {
                    check_error = -EUCLEAN;
                    break;
                }
                ctx->live_records[start]--;
            }
            check_sector += SWAPZ_SECTORS;
            check_remaining -= SWAPZ_SECTORS;
        }
        for (restore_sector = sector; restore_sector < check_sector;
             restore_sector += SWAPZ_SECTORS) {
            swapz_u32 logical = (swapz_u32)(restore_sector / SWAPZ_SECTORS);
            const struct swapz_map *m = &ctx->maps[logical];
            if (m->valid)
                ctx->live_records[m->start_block]++;
        }
        if (check_error)
            return check_error;
    }
    while (remaining) {
        swapz_u32 logical = (swapz_u32)(sector / SWAPZ_SECTORS);
        const struct swapz_map *old = &ctx->maps[logical];
        swapz_u32 old_segment = ~(swapz_u32)0;
        bool became_dead = false;
        if (old->valid && ctx->segment_mapped_pages) {
            old_segment = old->start_block / SWAPZ_SEGMENT_BLOCKS;
            became_dead = ctx->segment_mapped_pages[old_segment] == 1U;
        }
        error = swapz_discard_page(&ctx->authority, logical);
        if (error)
            return error;
        if (became_dead && old_segment != ctx->authority.open_segment) {
            error = swapz_discard_dead_segment(ctx, old_segment);
            if (error)
                return error;
        }
        ctx->discard_pages++;
        sector += SWAPZ_SECTORS;
        remaining -= SWAPZ_SECTORS;
    }
    return 0;
}
int main(void) {
    struct swapz_map maps[2] = {
        {.start_block=0, .generation=1, .extent_blocks=1, .valid=1},
        {.start_block=256, .generation=1, .extent_blocks=1, .valid=1}
    };
    uint8_t classes[PHYSICAL_BLOCKS] = {0};
    uint16_t live[PHYSICAL_BLOCKS] = {0};
    swapz_u32 mapped[2] = {1, 0}; // second segment false-zero corruption
    struct swapz_dm ctx = {
        .logical_pages=2, .physical_blocks=PHYSICAL_BLOCKS,
        .maps=maps, .extent_classes=classes, .live_records=live,
        .segment_mapped_pages=mapped,
    };
    struct bio whole = {.bi_iter.bi_sector=0, .sectors=2*SWAPZ_SECTORS};
    ctx.authority.open_segment = 0;
    ctx.authority.ctx = &ctx;
    classes[0]=classes[256]=1;
    live[0]=live[256]=1;
    int error = swapz_discard(&ctx, &whole);
    printf("errno=%d discard_pages=%u first_valid=%u first_generation=%u second_valid=%u second_generation=%u first_refs=%u second_refs=%u\n",error,ctx.discard_pages,maps[0].valid,maps[0].generation,maps[1].valid,maps[1].generation,live[0],live[256]);
    assert(error == -EUCLEAN && ctx.discard_pages == 1 &&
           maps[0].valid == 0 && maps[0].generation == 2 &&
           maps[1].valid == 1 && maps[1].generation == 1 &&
           live[0] == 0 && live[256] == 1);
    return 0;
}
