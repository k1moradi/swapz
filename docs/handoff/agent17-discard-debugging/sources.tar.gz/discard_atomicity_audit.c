#include <assert.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>
typedef uint64_t sector_t;
typedef uint32_t swapz_u32;
#define SWAPZ_SECTORS 8U
#define SWAPZ_SEGMENT_BLOCKS 256U
#define PHYSICAL_BLOCKS 512U
struct swapz_map { swapz_u32 start_block, generation; unsigned extent_blocks, valid; };
struct swapz_authority { swapz_u32 open_segment; };
struct swapz_dm { swapz_u32 logical_pages, physical_blocks; struct swapz_map *maps; uint8_t *extent_classes; uint16_t *live_records; swapz_u32 *segment_mapped_pages; struct swapz_authority authority; unsigned discard_pages; };
struct bio { struct { sector_t bi_sector; } bi_iter; sector_t sectors; };
static struct swapz_dm *current;
static sector_t bio_sectors(struct bio *bio) { return bio->sectors; }
static bool swapz_map_extent_bounds_valid(const struct swapz_dm *ctx,const struct swapz_map *map) { swapz_u32 start=map->start_block; unsigned blocks=map->extent_blocks; if(start>=ctx->physical_blocks||(blocks!=1&&blocks!=2&&blocks!=4))return false; return blocks<=ctx->physical_blocks-start && start%SWAPZ_SEGMENT_BLOCKS+blocks<=SWAPZ_SEGMENT_BLOCKS; }
/* Mirrors the relevant production authority failure: a valid mapping with a
 * zero mapped-page segment sidecar is EUCLEAN before that page is mutated. */
static int swapz_discard_page(struct swapz_authority *authority, swapz_u32 logical) {
    struct swapz_map *map=&current->maps[logical]; swapz_u32 seg;
    assert(authority==&current->authority);
    if (map->generation==UINT32_MAX) return -EOVERFLOW;
    if (map->valid) {
        if (map->start_block>=current->physical_blocks || !current->live_records[map->start_block]) return -EUCLEAN;
        seg=map->start_block/SWAPZ_SEGMENT_BLOCKS;
        if (!current->segment_mapped_pages[seg]) return -EUCLEAN;
        --current->live_records[map->start_block];
        --current->segment_mapped_pages[seg];
    }
    map->valid=0; ++map->generation; return 0;
}
static int swapz_discard_dead_segment(struct swapz_dm *ctx, swapz_u32 segment) { (void)ctx;(void)segment;return 0; }
/* Current production dm-target.c swapz_discard body, whitespace/comments elided only. */
static int swapz_discard(struct swapz_dm *ctx, struct bio *bio) {
    sector_t sector=bio->bi_iter.bi_sector, remaining=bio_sectors(bio); int error;
    if (sector%SWAPZ_SECTORS || remaining%SWAPZ_SECTORS || sector/SWAPZ_SECTORS>=ctx->logical_pages || remaining/SWAPZ_SECTORS>ctx->logical_pages-sector/SWAPZ_SECTORS) return -ERANGE;
    { sector_t check_sector=sector, check_remaining=remaining, restore_sector; int check_error=0;
      while(check_remaining){ swapz_u32 logical=(swapz_u32)(check_sector/SWAPZ_SECTORS); const struct swapz_map *m=&ctx->maps[logical];
        if(m->generation==UINT32_MAX){check_error=-EOVERFLOW;break;}
        if(m->valid){swapz_u32 start=m->start_block; if(!swapz_map_extent_bounds_valid(ctx,m)||ctx->extent_classes[start]!=m->extent_blocks||!ctx->live_records[start]){check_error=-EUCLEAN;break;} ctx->live_records[start]--;}
        check_sector+=SWAPZ_SECTORS;check_remaining-=SWAPZ_SECTORS;}
      for(restore_sector=sector;restore_sector<check_sector;restore_sector+=SWAPZ_SECTORS){swapz_u32 logical=(swapz_u32)(restore_sector/SWAPZ_SECTORS);const struct swapz_map *m=&ctx->maps[logical];if(m->valid)ctx->live_records[m->start_block]++;}
      if(check_error)return check_error; }
    while(remaining){swapz_u32 logical=(swapz_u32)(sector/SWAPZ_SECTORS);const struct swapz_map *old=&ctx->maps[logical];swapz_u32 old_segment=UINT32_MAX;bool became_dead=false;
      if(old->valid&&ctx->segment_mapped_pages){old_segment=old->start_block/SWAPZ_SEGMENT_BLOCKS;became_dead=ctx->segment_mapped_pages[old_segment]==1U;}
      error=swapz_discard_page(&ctx->authority,logical); if(error)return error;
      if(became_dead&&old_segment!=ctx->authority.open_segment){error=swapz_discard_dead_segment(ctx,old_segment);if(error)return error;}
      ctx->discard_pages++; sector+=SWAPZ_SECTORS;remaining-=SWAPZ_SECTORS; }
    return 0;
}
int main(void){struct swapz_dm ctx={0};struct swapz_map maps[2]={0};uint8_t classes[PHYSICAL_BLOCKS]={0};uint16_t live[PHYSICAL_BLOCKS]={0};swapz_u32 counts[2]={1,0};struct bio bio={{0},2*SWAPZ_SECTORS};
ctx.logical_pages=2;ctx.physical_blocks=PHYSICAL_BLOCKS;ctx.maps=maps;ctx.extent_classes=classes;ctx.live_records=live;ctx.segment_mapped_pages=counts;ctx.authority.open_segment=UINT32_MAX;current=&ctx;
maps[0]=(struct swapz_map){.start_block=0,.generation=1,.extent_blocks=1,.valid=1};maps[1]=(struct swapz_map){.start_block=SWAPZ_SEGMENT_BLOCKS,.generation=1,.extent_blocks=1,.valid=1};classes[0]=1;classes[SWAPZ_SEGMENT_BLOCKS]=1;live[0]=1;live[SWAPZ_SEGMENT_BLOCKS]=1;
int rc=swapz_discard(&ctx,&bio);printf("rc=%d page0_valid=%u gen0=%u live0=%u page1_valid=%u gen1=%u live1=%u discard_pages=%u\n",rc,maps[0].valid,maps[0].generation,live[0],maps[1].valid,maps[1].generation,live[SWAPZ_SEGMENT_BLOCKS],ctx.discard_pages);
assert(rc==-EUCLEAN);assert(!maps[0].valid && maps[0].generation==2 && live[0]==0);assert(maps[1].valid && maps[1].generation==1 && live[SWAPZ_SEGMENT_BLOCKS]==1);return 0;}
