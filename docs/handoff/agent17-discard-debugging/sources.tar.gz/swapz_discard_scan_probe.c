// SPDX-License-Identifier: GPL-2.0-only
#define _POSIX_C_SOURCE 200809L
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <inttypes.h>
#include <errno.h>
typedef uint32_t swapz_u32;
typedef uint8_t swapz_u8;
#define SWAPZ_SEGMENT_BLOCKS 256U
struct swapz_map {
    swapz_u32 start_block;
    swapz_u32 generation;
    swapz_u32 payload_offset;
    uint16_t payload_length;
    swapz_u8 record_index;
    union {
        swapz_u8 state;
        struct {
            swapz_u8 extent_blocks:3;
            swapz_u8 raw:1;
            swapz_u8 valid:1;
            swapz_u8 reserved:3;
        };
    };
};
_Static_assert(sizeof(struct swapz_map) == 16, "wrong production map width");
struct swapz_authority {
    struct swapz_map *maps;
    swapz_u32 logical_pages;
    swapz_u32 physical_blocks;
    swapz_u32 segment_count;
};
static int swapz_legal_class(swapz_u8 blocks)
{
    return blocks == 1U || blocks == 2U || blocks == 4U;
}
static int swapz_map_proof_refuse(const char *transition, const char *category,
                                  int error)
{
    (void)transition; (void)category; return error;
}
static inline void swapz_map_proof_resched(swapz_u32 logical) { (void)logical; }
/* Exact production non-physical-metadata proof control flow, modulo removal
 * of the unused kernel-only physical-descriptor verification branch. */
static int swapz_verify_segment_authoritative_maps(
    const struct swapz_authority *a, swapz_u32 segment,
    swapz_u32 expected_logical, swapz_u32 expected_count,
    int verify_physical_metadata, const char *transition)
{
    const swapz_u32 none = ~(swapz_u32)0;
    swapz_u32 logical, start_block, end_block, found_count = 0;
    if (!a || !a->maps || segment >= a->segment_count ||
        expected_count > a->logical_pages ||
        verify_physical_metadata ||
        (expected_logical != none &&
         (expected_logical >= a->logical_pages || expected_count != 1U)))
        return swapz_map_proof_refuse(transition, "invalid_request", -EINVAL);
    start_block = segment * SWAPZ_SEGMENT_BLOCKS;
    end_block = start_block + SWAPZ_SEGMENT_BLOCKS;
    for (logical = 0; logical < a->logical_pages; ++logical) {
        const struct swapz_map *map = &a->maps[logical];
        swapz_u32 map_end_block;
        swapz_map_proof_resched(logical);
        if (!map->valid)
            continue;
        if (map->start_block >= a->physical_blocks ||
            !swapz_legal_class(map->extent_blocks) ||
            map->extent_blocks > a->physical_blocks - map->start_block ||
            map->start_block % SWAPZ_SEGMENT_BLOCKS +
                map->extent_blocks > SWAPZ_SEGMENT_BLOCKS)
            return swapz_map_proof_refuse(
                transition, "extent_geometry", -EUCLEAN);
        map_end_block = map->start_block + map->extent_blocks;
        if (map->start_block >= end_block || map_end_block <= start_block)
            continue;
        if (expected_logical != none && logical != expected_logical)
            return swapz_map_proof_refuse(
                transition, "unexpected_logical", -EUCLEAN);
        if (found_count >= expected_count)
            return swapz_map_proof_refuse(
                transition, "unexpected_reference", -EUCLEAN);
        found_count++;
    }
    if (found_count != expected_count)
        return swapz_map_proof_refuse(
            transition, "reference_count", -EUCLEAN);
    return 0;
}
static uint64_t process_cpu_ns(void)
{
    struct timespec instant;
    if (clock_gettime(CLOCK_PROCESS_CPUTIME_ID, &instant))
        exit(2);
    return (uint64_t)instant.tv_sec * UINT64_C(1000000000)
         + (uint64_t)instant.tv_nsec;
}
static int run_case(swapz_u32 logical_pages, swapz_u32 discarded_pages,
                    int dense)
{
    struct swapz_map *maps = calloc(logical_pages, sizeof(*maps));
    if (!maps) return 1;
    const swapz_u32 physical_segments = discarded_pages + 64U;
    struct swapz_authority authority = {
        .maps = maps, .logical_pages = logical_pages,
        .segment_count = physical_segments,
        .physical_blocks = physical_segments * SWAPZ_SEGMENT_BLOCKS
    };
    if (logical_pages < discarded_pages) { free(maps); return 1; }
    for (swapz_u32 page = 0; page < discarded_pages; ++page) {
        maps[page].valid = 1;
        maps[page].extent_blocks = 1;
        maps[page].start_block = (page + 2U) * SWAPZ_SEGMENT_BLOCKS;
    }
    if (dense) {
        for (swapz_u32 page = discarded_pages; page < logical_pages; ++page) {
            maps[page].valid = 1;
            maps[page].extent_blocks = 1;
            maps[page].start_block = (discarded_pages + 2U + (page - discarded_pages) / 60000U)
                                   * SWAPZ_SEGMENT_BLOCKS;
        }
    }
    swapz_u32 full_map_scans = 0;
    uint64_t logical_examined = 0;
    const uint64_t started = process_cpu_ns();
    for (swapz_u32 page = 0; page < discarded_pages; ++page) {
        int error = swapz_verify_segment_authoritative_maps(
            &authority, page + 2U, page, 1U, 0, "discard_final_map");
        if (error) { fprintf(stderr, "scan failed page=%u error=%d\n", page, error); free(maps); return 1; }
        ++full_map_scans;
        logical_examined += logical_pages;
        maps[page].valid = 0;  // model a final-map DISCARD transition
    }
    const uint64_t cpu_ns = process_cpu_ns() - started;
    printf("logical_pages=%u discard_pages=%u layout=%s full_scans=%u "
           "examined=%" PRIu64 " alloc_in_loop=0 "
           "lower_reads_in_loop=0 decode_in_loop=0 "
           "cpu_total_ms=%.3f cpu_ms_per_1000=%.3f "
           "cpu_ms_per_100000=%.3f\n",
           logical_pages, discarded_pages, dense ? "dense" : "sparse",
           full_map_scans, logical_examined,
           (double)cpu_ns / 1000000.0,
           ((double)cpu_ns / (double)discarded_pages) / 1000.0,
           ((double)cpu_ns / (double)discarded_pages) / 10.0);
    free(maps);
    return 0;
}
int main(void)
{
    int errors = 0;
    errors |= run_case(262144U, 1000U, 0);
    errors |= run_case(262144U, 1000U, 1);
    errors |= run_case(1048576U, 1000U, 0);
    errors |= run_case(1048576U, 1000U, 1);
    errors |= run_case(262144U, 100000U, 0);
    errors |= run_case(262144U, 100000U, 1);
    return errors;
}
