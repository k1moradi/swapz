swapz V3 alpha.7 validation evidence

This archive contains the exact primary trial JSON files (including failed setup attempts), their kernel-log captures, the frozen 1024-page fixture, build records, exact-C test logs, live FUA/overwrite records, GC rotation records, full-destination negative-test records, suspend-matrix records and helper sources.

The successful primary trials are the five v22-b0, alpha6-b0/b1/b2, alpha7-b0/b1/b2 repetitions listed in reports/alpha7/primary-trials.csv. The alpha7-b0 repetition 1 uses the successful alpha7-b0-r1-retry2 directory because the earlier attempts were invalid helper/preflight attempts; those failures remain included.

Raw device mappings are not retained. Device Mapper and null_blk resources were ordinarily removed after test completion.
