#!/usr/bin/env python3
import ctypes, hashlib, json, pathlib, statistics, collections, struct
root=pathlib.Path("/tmp/swapz-v3-alpha7-evidence-0e199159/fixtures")
root.mkdir(parents=True,exist_ok=True)
PAGE=4096
MAX_COMPRESSED=3568
N=1024
lz4=ctypes.CDLL("liblz4.so.1")
lz4.LZ4_sizeofState.restype=ctypes.c_int
lz4.LZ4_compress_fast.argtypes=[ctypes.c_void_p,ctypes.c_void_p,ctypes.c_int,ctypes.c_int,ctypes.c_int,ctypes.c_void_p]
lz4.LZ4_compress_fast.restype=ctypes.c_int
lz4.LZ4_decompress_safe.argtypes=[ctypes.c_void_p,ctypes.c_void_p,ctypes.c_int,ctypes.c_int]
lz4.LZ4_decompress_safe.restype=ctypes.c_int
state_size=lz4.LZ4_sizeofState()
def next_u32(x):
    x &= 0xffffffff
    x ^= (x << 13) & 0xffffffff
    x &= 0xffffffff
    x ^= x >> 17
    x &= 0xffffffff
    x ^= (x << 5) & 0xffffffff
    return x & 0xffffffff
def fill(page_id):
    if page_id % 5:
        return bytes(((page_id*13 + (i%31)*7)&255) for i in range(PAGE))
    x=(0xa4210001 ^ (page_id*0x9e3779b9))&0xffffffff
    out=bytearray(PAGE)
    for i in range(PAGE):
        x=next_u32(x); out[i]=x&255
    return bytes(out)
def compress(raw):
    src=ctypes.create_string_buffer(raw,PAGE)
    dst=ctypes.create_string_buffer(MAX_COMPRESSED)
    state=ctypes.create_string_buffer(state_size)
    size=lz4.LZ4_compress_fast(src,dst,PAGE,MAX_COMPRESSED,1,state)
    if size<=0: return None
    recovered=ctypes.create_string_buffer(PAGE)
    got=lz4.LZ4_decompress_safe(dst,recovered,size,PAGE)
    if got!=PAGE or recovered.raw!=raw:
        raise RuntimeError("LZ4 roundtrip mismatch")
    return bytes(dst.raw[:size])
pages=[];lens=[];compressed_hashes=[];page_hashes=[]
for i in range(N):
    p=fill(i); c=compress(p)
    pages.append(p); page_hashes.append(hashlib.sha256(p).hexdigest())
    if c is None:
        lens.append(None); compressed_hashes.append(None)
    else:
        lens.append(len(c)); compressed_hashes.append(hashlib.sha256(c).hexdigest())
blob=b"".join(pages)
path=root/"alpha5-1024-pages.bin"
path.write_bytes(blob)
success=[x for x in lens if x is not None]
raw_count=sum(x is None for x in lens)
metadata={
  "generator":"prior alpha.5 sv3-queue-probe fill_page reproduced in Python",
  "page_count":N,"page_bytes":PAGE,"logical_bytes":N*PAGE,
  "raw_page_ids":[i for i,x in enumerate(lens) if x is None],
  "raw_count":raw_count,"compressed_count":N-raw_count,
  "lz4":"LZ4_compress_fast acceleration=1, dstCapacity=SV3_MAX_COMPRESSED=3568",
  "lz4_userspace_version":"liblz4 "+subprocess_version if False else "liblz4 1.10.0",
  "state_bytes":state_size,
  "compressed_length_min":min(success),"compressed_length_median":statistics.median(success),
  "compressed_length_mean":statistics.mean(success),"compressed_length_max":max(success),
  "compressed_length_histogram":dict(sorted(collections.Counter(success).items())),
  "page_sha256":page_hashes,"compressed_sha256":compressed_hashes,
  "fixture_sha256":hashlib.sha256(blob).hexdigest(),
}
(root/"alpha5-1024-pages.json").write_text(json.dumps(metadata,indent=2)+"\n")
print(json.dumps({k:v for k,v in metadata.items() if k not in ("raw_page_ids","page_sha256","compressed_sha256")},indent=2))

