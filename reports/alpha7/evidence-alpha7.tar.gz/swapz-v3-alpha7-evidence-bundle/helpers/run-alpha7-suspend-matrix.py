#!/usr/bin/env python3
import json,pathlib,re,subprocess,sys,time
root=pathlib.Path('/tmp/swapz-v3-alpha7-evidence-0e199159'); helper_dir=root/'helpers'/'queue-probe'; module=helper_dir/'sv3-queue-probe.ko'; verifier=helper_dir/'verify-queue'; backing='nullb_swapz3_a7_0e199159'; backdev='251:0'; base=root/'suspend-matrix-5ms'
name_prefix='swapz3-a7-queue'; uuid_prefix='SWZ-A7-QUEUE'
class Stop(Exception): pass
def run(args,timeout=60):
 try: p=subprocess.run(args,text=True,capture_output=True,timeout=timeout)
 except subprocess.TimeoutExpired as e: raise Stop(f'TIMEOUT {args}: {e}')
 return p
def save(path,obj): path.write_text(json.dumps(obj,indent=2)+'\n')
def must(args,timeout=60):
 p=run(args,timeout)
 if p.returncode: raise Stop(f'command failed rc={p.returncode}: {args}\n{p.stdout}\n{p.stderr}')
 return p
def status(name):
 p=must(['sudo','-n','dmsetup','status',name],10); s=p.stdout.strip(); f=dict(re.findall(r'([a-z0-9_]+)=([^ ]+)',s))
 if not f: raise Stop('malformed target status')
 return s,{k:int(v) if v.lstrip('-').isdigit() else v for k,v in f.items()}
def get_stat():
 s=must(['sudo','-n','cat',f'/sys/block/{backing}/stat'],10).stdout.strip(); x=[int(t) for t in s.split()]
 return s,{'read_reqs':x[0],'read_sectors':x[2],'write_reqs':x[4],'write_sectors':x[6],'flushes':x[15] if len(x)>15 else None}
def one(delay):
 name=f'{name_prefix}-{delay}ms'; uuid=f'{uuid_prefix}-{delay}MS'; d=base/f'coalesce-{delay}ms'; d.mkdir(parents=True,exist_ok=True)
 table=f'0 8192 swapz3 {backdev} 0 64 0 2 {delay} 0 1'
 (d/'table.expected').write_text(table+'\n')
 before_dmesg=must(['sudo','-n','dmesg','--ctime'],10).stdout; (d/'dmesg-before.txt').write_text(before_dmesg)
 info=run(['sudo','-n','dmsetup','info','-c','--noheadings','-o','name,uuid,open,attr',name],10)
 if info.returncode==0: raise Stop(f'target collision {name}: {info.stdout}')
 p=must(['sudo','-n','dmsetup','create',name,'--uuid',uuid,'--noudevrules','--noudevsync','--table',table],30)
 (d/'dm-create.stdout').write_text(p.stdout); (d/'dm-create.stderr').write_text(p.stderr)
 info=must(['sudo','-n','dmsetup','info','-c','--noheadings','-o','name,uuid,major,minor,open,attr',name],10).stdout.strip(); (d/'info-before.txt').write_text(info+'\n')
 f=info.split(':')
 if len(f)<6 or f[0]!=name or f[1]!=uuid or f[-2]!='0' or f[-1]!='L--w': raise Stop(f'bad target info {info}')
 dmdev=f'/dev/dm-{f[3]}'
 actual_table=must(['sudo','-n','dmsetup','table',name],10).stdout.strip(); (d/'table.actual').write_text(actual_table+'\n')
 if actual_table!=table: raise Stop(f'table mismatch {actual_table!r} expected={table!r}')
 # Verify the exact backing, its null_blk config, and no mount/swap/foreign holder.
 if pathlib.Path(f'/sys/dev/block/{backdev}').resolve().name!=backing: raise Stop('backing major:minor provenance mismatch')
 for field,val in [('memory_backed','1'),('size','40'),('blocksize','512'),('completion_nsec','5000000'),('mbps','20')]:
  observed=pathlib.Path(f'/sys/kernel/config/nullb/{backing}/{field}').read_text().strip()
  if observed!=val: raise Stop(f'null_blk {field} mismatch {observed!r}')
 if pathlib.Path(f'/sys/devices/virtual/block/{backing}/holders/{name.replace("-","-")}').exists(): pass
 if subprocess.run(['findmnt','-rn','-S',f'/dev/{backing}'],capture_output=True).returncode==0: raise Stop('backing unexpectedly mounted')
 if f'/dev/{backing}' in pathlib.Path('/proc/swaps').read_text(): raise Stop('backing unexpectedly active swap')
 holders=sorted(x.name for x in pathlib.Path(f'/sys/devices/virtual/block/{backing}/holders').iterdir())
 if holders!=[f'dm-{f[3]}']: raise Stop(f'backing holder mismatch before helper: {holders}')
 stat_before,stat_obj_before=get_stat(); (d/'stat-before.txt').write_text(stat_before+'\n')
 # Run the exact source-built helper against only this verified owned mapping.
 cmd=['sudo','-n','insmod',str(module),f'target={dmdev}','count=1024']
 start=time.monotonic_ns(); proc=subprocess.Popen(cmd,stdout=open(d/'insmod.stdout','w'),stderr=open(d/'insmod.stderr','w'),text=True)
 (d/'insmod.pid').write_text(f'{proc.pid}\n'); submitted=None; marker_key=f'SV3QUEUE begin target={dmdev} count=1024'; begin_count=before_dmesg.count(marker_key)
 deadline=time.monotonic()+30
 while time.monotonic()<deadline:
  logs=must(['sudo','-n','dmesg','--ctime'],10).stdout
  (d/'dmesg-during-submit.txt').write_text(logs)
  lines=logs.splitlines(); starts=[i for i,line in enumerate(lines) if marker_key in line]
  if len(starts)>begin_count:
   for line in lines[starts[-1]+1:]:
    if 'SV3QUEUE submitted=1024' in line: submitted=line; break
    if 'SV3QUEUE done submitted=1024' in line: break
  if submitted: break
  if proc.poll() is not None: raise Stop(f'helper exited before submitted marker rc={proc.returncode}; inspect exact marker history')
  time.sleep(.002)
 if not submitted: raise Stop('no submitted marker within 30s')
 (d/'submitted-marker.txt').write_text(submitted+'\n')
 m=re.search(r'outstanding=(\d+)',submitted)
 if not m: raise Stop(f'bad submitted marker {submitted}')
 outstanding=int(m.group(1)); (d/'observed-outstanding.txt').write_text(f'{outstanding}\n')
 if outstanding==0: raise Stop('queue already drained at submitted marker; no in-flight suspend evidence')
 # Ordinary bounded suspend must drain all accepted BIOs.
 p=must(['sudo','-n','timeout','90s','dmsetup','suspend',name],100)
 (d/'suspend.stdout').write_text(p.stdout); (d/'suspend.stderr').write_text(p.stderr)
 suspended=must(['sudo','-n','dmsetup','info','-c','--noheadings','-o','name,uuid,open,attr',name],10).stdout.strip(); (d/'info-suspended.txt').write_text(suspended+'\n')
 if uuid not in suspended or suspended.split(':')[-1]!='L-sw': raise Stop(f'target not suspended: {suspended}')
 try: hrc=proc.wait(timeout=30)
 except subprocess.TimeoutExpired: raise Stop('helper remains blocked after ordinary suspend')
 (d/'insmod.exit').write_text(f'{hrc}\n')
 if hrc: raise Stop(f'helper returned {hrc}')
 after_dmesg=must(['sudo','-n','dmesg','--ctime'],10).stdout; (d/'dmesg-after-submit.txt').write_text(after_dmesg)
 markers=[line for line in after_dmesg.splitlines() if 'SV3QUEUE done submitted=1024' in line]
 if not markers or 'completed=1024 errors=0' not in markers[-1]: raise Stop('not all 1024 BIOs completed exactly once successfully')
 mod=must(['sudo','-n','lsmod'],10).stdout
 if 'sv3_queue_probe' not in mod: raise Stop('test helper module not loaded after success')
 p=must(['sudo','-n','rmmod','sv3_queue_probe'],20); (d/'helper-rmmod.stdout').write_text(p.stdout); (d/'helper-rmmod.stderr').write_text(p.stderr)
 p=must(['sudo','-n','dmsetup','resume',name],20)
 verify=must(['sudo','-n',str(verifier),dmdev,'1024'],60); (d/'readback.stdout').write_text(verify.stdout); (d/'readback.stderr').write_text(verify.stderr)
 if 'verify_pages=1024 errors=0 result=PASS' not in verify.stdout: raise Stop('full byte verification failed')
 stxt,s=status(name); (d/'status-after-readback.txt').write_text(stxt+'\n')
 required=['logical_write=4194304','compressed=819','raw=205','failed=0','error=0']
 if any(v not in stxt for v in required): raise Stop(f'logical completion counters mismatch: {stxt}')
 fields=s
 windows=fields['windows']; hist=sum(fields[k] for k in ['win1','win2','win3_4','win5_8','win9_16','win17_64'])
 if hist!=windows or fields['window_records']!=1024: raise Stop(f'window histogram does not reconcile windows={windows} hist={hist} records={fields["window_records"]}')
 stat_after,stat_obj_after=get_stat(); (d/'stat-after.txt').write_text(stat_after+'\n')
 delta={k:stat_obj_after[k]-stat_obj_before[k] for k in stat_obj_after}
 (d/'stat-delta.json').write_text(json.dumps(delta,indent=2)+'\n')
 pre_remove=must(['sudo','-n','dmsetup','info','-c','--noheadings','-o','name,uuid,open,attr',name],10).stdout.strip()
 if uuid not in pre_remove or ':0:L--w' not in pre_remove: raise Stop(f'pre-remove identity/open mismatch {pre_remove}')
 must(['sudo','-n','dmsetup','remove','--uuid',uuid],30)
 absent=run(['sudo','-n','dmsetup','info','-c','--noheadings','-o','name,uuid',name],10)
 if absent.returncode==0: raise Stop(f'target remains after ordinary removal: {absent.stdout}')
 end_dmesg=must(['sudo','-n','dmesg','--ctime'],10).stdout; (d/'dmesg-after.txt').write_text(end_dmesg)
 (d/'verdict.txt').write_text(f'PASS: coalesce_ms={delay}; 1024 submitted, 1024 completed with zero errors; ordinary suspend/drain/resume; byte-exact 1024-page readback; ordinary UUID removal.\n')
 report={'coalesce_ms':delay,'table':table,'dm_device':dmdev,'submitted_marker':submitted,'observed_outstanding':outstanding,'helper_return':hrc,'status':fields,'window_histogram_total':hist,'backing_stat_delta':delta,'byte_readback':'PASS','ordinary_teardown':'PASS','elapsed_ns':time.monotonic_ns()-start}
 save(d/'result.json',report)
 print('SUSPEND_MATRIX_PASS '+json.dumps({'coalesce_ms':delay,'outstanding_at_marker':outstanding,'windows':windows,'window_records':fields['window_records'],'win1':fields['win1'],'win2':fields['win2'],'win3_4':fields['win3_4'],'win5_8':fields['win5_8'],'win9_16':fields['win9_16'],'win17_64':fields['win17_64'],'deferred':fields['coalesce_deferred'],'urgent':fields['coalesce_urgent'],'requeues':fields['worker_requeues'],'readback':'PASS','teardown':'PASS'},sort_keys=True),flush=True)

def quarantine(msg):
 (base/'RUNNER_FAILURE.txt').write_text(msg+'\n')
 print('RUNNER_FAILURE: '+msg,file=sys.stderr)
try:
 for delay in (0,1,2,4): one(delay)
except Exception as exc:
 quarantine(str(exc)); sys.exit(1)
(base/'MATRIX_PASS.txt').write_text('all four coalescing delays passed 1024-BIO suspend/drain/resume and exact data readback\n')
