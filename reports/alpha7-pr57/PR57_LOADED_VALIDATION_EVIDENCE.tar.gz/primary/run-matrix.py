#!/usr/bin/env python3
import hashlib,json,os,subprocess,sys,time
from pathlib import Path
BASE=Path("/root/swapz-pr57-validation")
EVID=BASE/"evidence/primary"
RUNNER=EVID/"run-primary-trial.py"
PROBE=BASE/"evidence/helpers/queue/sv3_queue_probe.ko"
VERIFY=BASE/"evidence/helpers/queue/verify-queue"
configs=[
 {"name":"v22","impl":"v22","bulk":0,"src":"3a89ebbeba21c814dcf724e227b31d38445a3f9a","mod":BASE/"v22/kernel/dm-swapz.ko"},
 {"name":"alpha6-b1","impl":"alpha6","bulk":1,"src":"4324c98497891147896ad817f4593c5cc198953b","mod":BASE/"alpha6/kernel/extent-v3/dm-swapz.ko"},
 {"name":"alpha7-b1","impl":"alpha7","bulk":1,"src":"0e199159cea3dd479224ce59513ee9c0a810a0d6","mod":BASE/"alpha7/kernel/extent-v3/dm-swapz.ko"},
 {"name":"pr57-b0","impl":"pr57","bulk":0,"src":"2e71c0c90b7f6f4ec96340583a0bc5c517bae97c","mod":BASE/"pr57/kernel/extent-v3/dm-swapz.ko"},
 {"name":"pr57-b1","impl":"pr57","bulk":1,"src":"2e71c0c90b7f6f4ec96340583a0bc5c517bae97c","mod":BASE/"pr57/kernel/extent-v3/dm-swapz.ko"},
 {"name":"pr57-b2","impl":"pr57","bulk":2,"src":"2e71c0c90b7f6f4ec96340583a0bc5c517bae97c","mod":BASE/"pr57/kernel/extent-v3/dm-swapz.ko"},
]
def cmd(argv,timeout=90):
 t=time.monotonic_ns(); p=subprocess.run(argv,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=timeout)
 return {"argv":argv,"rc":p.returncode,"output":p.stdout,"elapsed_ns":time.monotonic_ns()-t}
def checked(argv,timeout=90):
 r=cmd(argv,timeout)
 if r["rc"]: raise RuntimeError(f"command failed {argv}: {r}")
 return r
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def loaded_src():
 p=Path("/sys/module/dm_swapz/srcversion")
 return p.read_text().strip() if p.exists() else None
def dm_empty():
 s=checked(["dmsetup","ls","--noheadings"])["output"].strip()
 return not s or s=="No devices found"
def switch(c):
 if not dm_empty(): raise RuntimeError("DM mappings exist before module switch")
 if Path("/sys/module/sv3_queue_probe").exists(): raise RuntimeError("probe remains loaded")
 if not c["mod"].is_file(): raise RuntimeError(f"module missing {c[mod]}")
 info=checked(["modinfo","-F","srcversion",str(c["mod"])])["output"].strip()
 expected_hash=sha(c["mod"])
 current=loaded_src()
 events=[]
 if current!=info:
  if current is not None:
   rows=[x.split() for x in checked(["lsmod"])["output"].splitlines()[1:] if x.split() and x.split()[0]=="dm_swapz"]
   if len(rows)!=1 or rows[0][2]!="0": raise RuntimeError(f"current module is not unreferenced: {rows}")
   events.append(checked(["rmmod","dm_swapz"],30))
   if loaded_src() is not None: raise RuntimeError("old module remains after rmmod")
  events.append(checked(["insmod",str(c["mod"])],30))
  if loaded_src()!=info: raise RuntimeError(f"loaded srcversion {loaded_src()} != selected {info}")
 if sha(c["mod"])!=expected_hash: raise RuntimeError("module changed during trial")
 targets=checked(["dmsetup","targets"])["output"].splitlines()
 wanted="swapz" if c["impl"]=="v22" else "swapz3"
 if not any(x.split() and x.split()[0]==wanted for x in targets): raise RuntimeError(f"target {wanted} absent")
 event={"name":c["name"],"source_sha":c["src"],"module_path":str(c["mod"]),"module_sha256":expected_hash,"srcversion":info,"switch":events,"loaded_srcversion":loaded_src()}
 with (EVID/"module-switches.jsonl").open("a") as f:f.write(json.dumps(event)+"\n")
 return expected_hash,info
orders=[]
reps={c["name"]:0 for c in configs}
for rnd in range(5):
 seq=configs[:]
 shift=rnd%len(seq)
 seq=seq[shift:]+seq[:shift]
 if rnd%2: seq.reverse()
 orders.append(seq)
for rnd,seq in enumerate(orders,1):
 for c in seq:
  rep=reps[c["name"]]+1; reps[c["name"]]=rep
  module_hash,srcversion=switch(c)
  label=f"{c["name"]}-r{rep}"
  out=EVID/"trials"/label
  args=["python3",str(RUNNER),"--implementation",c["impl"],"--bulk",str(c["bulk"]),"--repetition",str(rep),"--module",str(c["mod"]),"--module-sha256",module_hash,"--module-srcversion",srcversion,"--probe",str(PROBE),"--verifier",str(VERIFY),"--output",str(out)]
  p=cmd(args,timeout=180)
  rec={"round":rnd,"config":c["name"],"rep":rep,"command":args,"rc":p["rc"],"output":p["output"],"start":time.time()}
  (out.parent/(label+".runner.json")).write_text(json.dumps(rec,indent=2)+"\n") if out.exists() else None
  with (EVID/"matrix-run.jsonl").open("a") as f:f.write(json.dumps(rec)+"\n")
  print(json.dumps({"round":rnd,"config":c["name"],"rep":rep,"rc":p["rc"],"summary":p["output"].strip()[-700:]},sort_keys=True))
  if p["rc"]!=0: raise SystemExit(f"trial failed; evidence preserved at {out}")
print("ALL_PRIMARY_REPS_COMPLETE",reps)
