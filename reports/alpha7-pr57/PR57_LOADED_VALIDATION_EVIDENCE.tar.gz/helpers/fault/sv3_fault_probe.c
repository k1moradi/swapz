// Test-only upper BIO helper for PR #57 target-local lower-write EIO checks.
// It uses only the caller-supplied, independently verified test DM mapping.
#include <linux/bio.h>
#include <linux/blkdev.h>
#include <linux/completion.h>
#include <linux/highmem.h>
#include <linux/module.h>
#include <linux/slab.h>

#define PAGE_BYTES 4096U
struct probe_item {
	struct completion done;
	struct bio *bio;
	struct page *page;
	int status;
};
static char *target;
static unsigned int mode = 2; /* 0 compressed, 1 raw, 2 compressed then raw */
static unsigned int groups = 2;
module_param(target, charp, 0400);
MODULE_PARM_DESC(target, "verified test-owned DM block node");
module_param(mode, uint, 0400);
MODULE_PARM_DESC(mode, "0=compressed, 1=raw, 2=mixed pair");
module_param(groups, uint, 0400);
MODULE_PARM_DESC(groups, "number of two-write groups (1..4)");

static void fill_page(u8 *dst, u32 page_id, bool raw)
{
	u32 i;
	if (!raw) {
		memset(dst, 0x41U + (page_id & 0x1fU), PAGE_BYTES);
		return;
	}
	{
		u32 x = 0x9e3779b9U ^ (page_id * 0x85ebca6bU);
		for (i = 0; i < PAGE_BYTES; ++i) {
			x ^= x << 13;
			x ^= x >> 17;
			x ^= x << 5;
			dst[i] = (u8)x;
		}
	}
}

static void probe_end_io(struct bio *bio)
{
	struct probe_item *item = bio->bi_private;

	item->status = blk_status_to_errno(bio->bi_status);
	complete(&item->done);
}

static int wait_item(struct probe_item *item, const char *kind, u32 group,
		     u32 slot)
{
	unsigned long waited = wait_for_completion_timeout(&item->done, 60 * HZ);

	if (!waited) {
		pr_err("SV3FAULT timeout group=%u kind=%s slot=%u; retain bio/page until completion\n",
		       group, kind, slot);
		wait_for_completion(&item->done);
	}
	return item->status;
}

static void release_item(struct probe_item *item)
{
	if (item->bio)
		bio_put(item->bio);
	if (item->page)
		__free_page(item->page);
	item->bio = NULL;
	item->page = NULL;
}

static int submit_group(struct block_device *bdev, u32 group)
{
	struct probe_item writes[2] = { };
	struct probe_item barrier = { };
	int status[2] = { -EINPROGRESS, -EINPROGRESS };
	int flush_status = -EINPROGRESS;
	int setup_error = 0;
	u32 i;

	for (i = 0; i < 2; ++i) {
		void *addr;
		bool raw = mode == 1 || (mode == 2 && i == 1);
		u32 logical = group * 2U + i;

		init_completion(&writes[i].done);
		writes[i].page = alloc_page(GFP_KERNEL);
		if (!writes[i].page) {
			setup_error = -ENOMEM;
			goto pre_submit_fail;
		}
		addr = kmap_local_page(writes[i].page);
		fill_page(addr, logical, raw);
		kunmap_local(addr);
		writes[i].bio = bio_alloc(bdev, 1, REQ_OP_WRITE, GFP_KERNEL);
		if (!writes[i].bio) {
			setup_error = -ENOMEM;
			goto pre_submit_fail;
		}
		writes[i].bio->bi_iter.bi_sector = (sector_t)logical * 8U;
		writes[i].bio->bi_private = &writes[i];
		writes[i].bio->bi_end_io = probe_end_io;
		if (bio_add_page(writes[i].bio, writes[i].page,
				 PAGE_BYTES, 0) != PAGE_BYTES) {
			setup_error = -EIO;
			goto pre_submit_fail;
		}
	}
	init_completion(&barrier.done);
	barrier.bio = bio_alloc(bdev, 0,
				REQ_OP_WRITE | REQ_PREFLUSH, GFP_KERNEL);
	if (!barrier.bio) {
		setup_error = -ENOMEM;
		goto pre_submit_fail;
	}
	barrier.bio->bi_iter.bi_sector = 0;
	barrier.bio->bi_private = &barrier;
	barrier.bio->bi_end_io = probe_end_io;

	pr_info("SV3FAULT submit group=%u mode=%u logical=%u,%u\n",
		group, mode, group * 2U, group * 2U + 1U);
	submit_bio(writes[0].bio);
	submit_bio(writes[1].bio);
	submit_bio(barrier.bio);
	status[0] = wait_item(&writes[0], "write", group, 0);
	status[1] = wait_item(&writes[1], "write", group, 1);
	flush_status = wait_item(&barrier, "preflush", group, 0);
	pr_info("SV3FAULT group=%u write0=%d write1=%d preflush=%d\n",
		group, status[0], status[1], flush_status);
	for (i = 0; i < 2; ++i)
		release_item(&writes[i]);
	release_item(&barrier);
	return status[0] || status[1] || flush_status ? -EIO : 0;

pre_submit_fail:
	for (i = 0; i < 2; ++i)
		release_item(&writes[i]);
	release_item(&barrier);
	return setup_error;
}

static int __init sv3_fault_probe_init(void)
{
	struct file *file;
	struct block_device *bdev;
	unsigned int group, completed = 0;
	int error = 0;

	if (!target || !groups || groups > 4 || mode > 2)
		return -EINVAL;
	file = bdev_file_open_by_path(target,
				      BLK_OPEN_READ | BLK_OPEN_WRITE,
				      THIS_MODULE, NULL);
	if (IS_ERR(file))
		return PTR_ERR(file);
	bdev = file_bdev(file);
	pr_info("SV3FAULT begin target=%s mode=%u groups=%u\n",
		target, mode, groups);
	for (group = 0; group < groups; ++group) {
		error = submit_group(bdev, group);
		if (error)
			break;
		completed++;
	}
	pr_info("SV3FAULT done groups_completed=%u groups_requested=%u error=%d\n",
		completed, groups, error);
	fput(file);
	return 0; /* Expected EIO is reported in per-BIO events, not helper load. */
}

static void __exit sv3_fault_probe_exit(void)
{
	pr_info("SV3FAULT unloaded\n");
}
module_init(sv3_fault_probe_init);
module_exit(sv3_fault_probe_exit);
MODULE_LICENSE("GPL");
MODULE_DESCRIPTION("PR #57 target-local lower-write fault BIO probe");
