savedcmd_modules.order := {   echo sv3_fault_probe.o; :; } > modules.order
