#include <linux/module.h>
#include <linux/export-internal.h>
#include <linux/compiler.h>

MODULE_INFO(name, KBUILD_MODNAME);

__visible struct module __this_module
__section(".gnu.linkonce.this_module") = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};



static const struct modversion_info ____versions[]
__used __section("__versions") = {
	{ 0xd272d446, "__fentry__" },
	{ 0x35aa6a66, "blk_status_to_errno" },
	{ 0xc19e177c, "bio_put" },
	{ 0x62cbec20, "complete" },
	{ 0x0f96d1ab, "bdev_file_open_by_path" },
	{ 0xcfb89cb3, "file_bdev" },
	{ 0xbd03ed67, "random_kmalloc_seed" },
	{ 0xa65b83f9, "kmalloc_caches" },
	{ 0xce56ea17, "__kmalloc_cache_noprof" },
	{ 0xd710adbf, "__kmalloc_noprof" },
	{ 0xc2ccdd1e, "__init_swait_queue_head" },
	{ 0x8f714034, "alloc_pages_noprof" },
	{ 0xbd03ed67, "vmemmap_base" },
	{ 0xbd03ed67, "page_offset_base" },
	{ 0x525d083c, "fs_bio_set" },
	{ 0xee423443, "bio_alloc_bioset" },
	{ 0x9d70f9a8, "bio_add_page" },
	{ 0xa7a7bb12, "submit_bio" },
	{ 0xe1b0a92a, "wait_for_completion_timeout" },
	{ 0x62cbec20, "wait_for_completion" },
	{ 0xfc70d3be, "__free_pages" },
	{ 0xcb8b6ec6, "kfree" },
	{ 0x88beff44, "fput" },
	{ 0xcc1d5ac5, "param_ops_uint" },
	{ 0xcc1d5ac5, "param_ops_charp" },
	{ 0xe8213e80, "_printk" },
	{ 0xd272d446, "__x86_return_thunk" },
	{ 0xe9196a28, "module_layout" },
};

static const u32 ____version_ext_crcs[]
__used __section("__version_ext_crcs") = {
	0xd272d446,
	0x35aa6a66,
	0xc19e177c,
	0x62cbec20,
	0x0f96d1ab,
	0xcfb89cb3,
	0xbd03ed67,
	0xa65b83f9,
	0xce56ea17,
	0xd710adbf,
	0xc2ccdd1e,
	0x8f714034,
	0xbd03ed67,
	0xbd03ed67,
	0x525d083c,
	0xee423443,
	0x9d70f9a8,
	0xa7a7bb12,
	0xe1b0a92a,
	0x62cbec20,
	0xfc70d3be,
	0xcb8b6ec6,
	0x88beff44,
	0xcc1d5ac5,
	0xcc1d5ac5,
	0xe8213e80,
	0xd272d446,
	0xe9196a28,
};
static const char ____version_ext_names[]
__used __section("__version_ext_names") =
	"__fentry__\0"
	"blk_status_to_errno\0"
	"bio_put\0"
	"complete\0"
	"bdev_file_open_by_path\0"
	"file_bdev\0"
	"random_kmalloc_seed\0"
	"kmalloc_caches\0"
	"__kmalloc_cache_noprof\0"
	"__kmalloc_noprof\0"
	"__init_swait_queue_head\0"
	"alloc_pages_noprof\0"
	"vmemmap_base\0"
	"page_offset_base\0"
	"fs_bio_set\0"
	"bio_alloc_bioset\0"
	"bio_add_page\0"
	"submit_bio\0"
	"wait_for_completion_timeout\0"
	"wait_for_completion\0"
	"__free_pages\0"
	"kfree\0"
	"fput\0"
	"param_ops_uint\0"
	"param_ops_charp\0"
	"_printk\0"
	"__x86_return_thunk\0"
	"module_layout\0"
;

MODULE_INFO(depends, "");


MODULE_INFO(srcversion, "103ABA1C0E7A5FC552BB7D6");
