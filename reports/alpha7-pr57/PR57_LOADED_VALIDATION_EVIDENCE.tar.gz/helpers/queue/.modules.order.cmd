savedcmd_modules.order := {   echo sv3_queue_probe.o; :; } > modules.order
