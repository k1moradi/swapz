#define _GNU_SOURCE
#include <errno.h>
#include <fcntl.h>
#include <inttypes.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#define PAGE 4096U
static int io_full(int fd, void *buf, off_t off, int write_op)
{
    ssize_t n = write_op ? pwrite(fd, buf, PAGE, off) : pread(fd, buf, PAGE, off);
    if (n == (ssize_t)PAGE) return 0;
    if (n >= 0) errno = EIO;
    return -1;
}
static int verify_all(int fd, unsigned pages, unsigned *map, unsigned char *fixture, unsigned char *buf)
{
    unsigned bad = 0;
    for (unsigned p = 0; p < pages; ++p) {
        if (io_full(fd, buf, (off_t)p * PAGE, 0)) {
            fprintf(stderr, "READ_FAIL page=%u errno=%d\n", p, errno);
            return -1;
        }
        if (memcmp(buf, fixture + (size_t)map[p] * PAGE, PAGE)) {
            if (bad < 8) fprintf(stderr, "MISMATCH page=%u expected_fixture=%u\n", p, map[p]);
            ++bad;
        }
    }
    printf("VERIFY pages=%u mismatches=%u result=%s\n", pages, bad, bad ? "FAIL" : "PASS");
    return bad ? -1 : 0;
}
int main(int argc, char **argv)
{
    const char *dev = NULL, *fixture_path = NULL;
    unsigned pages = 8192, hot_pages = 128, overwrites = 1024, trigger_page = 0;
    int expect_eio = 0;
    for (int i = 1; i < argc; ++i) {
        if (!strcmp(argv[i], "--device") && ++i < argc) dev = argv[i];
        else if (!strcmp(argv[i], "--fixture") && ++i < argc) fixture_path = argv[i];
        else if (!strcmp(argv[i], "--pages") && ++i < argc) pages = strtoul(argv[i], NULL, 10);
        else if (!strcmp(argv[i], "--hot-pages") && ++i < argc) hot_pages = strtoul(argv[i], NULL, 10);
        else if (!strcmp(argv[i], "--overwrites") && ++i < argc) overwrites = strtoul(argv[i], NULL, 10);
        else if (!strcmp(argv[i], "--trigger-page") && ++i < argc) trigger_page = strtoul(argv[i], NULL, 10);
        else if (!strcmp(argv[i], "--expect-write-eio")) expect_eio = 1;
        else { fprintf(stderr, "usage: %s --device DMDEV --fixture pages.bin [--pages N --hot-pages N --overwrites N --trigger-page N --expect-write-eio]\n", argv[0]); return 2; }
    }
    if (!dev || !fixture_path || pages < 512 || hot_pages < 1 || hot_pages >= pages || trigger_page >= pages) return 2;
    int ff = open(fixture_path, O_RDONLY | O_CLOEXEC);
    if (ff < 0) { perror("open fixture"); return 2; }
    off_t end = lseek(ff, 0, SEEK_END);
    if (end <= 0 || end % PAGE) { fprintf(stderr, "fixture must contain aligned 4K pages\n"); return 2; }
    unsigned fixture_pages = (unsigned)(end / PAGE);
    unsigned char *fixture = NULL, *buf = NULL;
    if (posix_memalign((void **)&fixture, PAGE, (size_t)end) || posix_memalign((void **)&buf, PAGE, PAGE)) return 2;
    if (pread(ff, fixture, (size_t)end, 0) != end) { perror("read fixture"); return 2; }
    close(ff);
    unsigned *map = calloc(pages, sizeof(*map));
    if (!map) return 2;
    int fd = open(dev, O_RDWR | O_DIRECT | O_CLOEXEC);
    if (fd < 0) { perror("open test target"); return 2; }
    uint64_t submitted = 0;
    for (unsigned p = 0; p < pages; ++p) {
        map[p] = p % fixture_pages;
        if (io_full(fd, fixture + (size_t)map[p] * PAGE, (off_t)p * PAGE, 1)) {
            fprintf(stderr, "INITIAL_WRITE_FAIL page=%u errno=%d\n", p, errno); return 1;
        }
        ++submitted;
    }
    printf("INITIAL_WRITES=%u\n", pages);
    if (verify_all(fd, pages, map, fixture, buf)) return 1;
    for (unsigned i = 0; i < overwrites; ++i) {
        unsigned slot = i % hot_pages;
        unsigned fi = (i * 37U + 19U) % fixture_pages;
        if (io_full(fd, fixture + (size_t)fi * PAGE, (off_t)slot * PAGE, 1)) {
            int write_errno = errno;
            fprintf(stderr, "OVERWRITE_FAIL index=%u slot=%u errno=%d\n", i, slot, write_errno);
            if (expect_eio && write_errno == EIO) {
                printf("EXPECTED_PRESSURE_WRITE_EIO index=%u slot=%u\n", i, slot);
                puts("NO_POST_FAILURE_READS_ISSUED");
                return 0;
            }
            return 1;
        }
        map[slot] = fi;
        ++submitted;
        if ((i & 255U) == 255U && verify_all(fd, pages, map, fixture, buf)) {
            fprintf(stderr, "PREFIX_VERIFY_FAIL overwrite_index=%u\n", i);
            return 1;
        }
    }
    printf("OVERWRITES=%u hot_pages=%u\n", overwrites, hot_pages);
    if (verify_all(fd, pages, map, fixture, buf)) return 1;
    unsigned trigger_fixture = (trigger_page * 53U + 7U) % fixture_pages;
    errno = 0;
    int trigger_rc = io_full(fd, fixture + (size_t)trigger_fixture * PAGE,
                             (off_t)trigger_page * PAGE, 1);
    int trigger_errno = trigger_rc ? errno : 0;
    printf("TRIGGER page=%u expected_fixture=%u rc=%d errno=%d pretrigger_successful_logical_writes=%" PRIu64 "\n",
           trigger_page, trigger_fixture, trigger_rc, trigger_errno, submitted);
    if (expect_eio) {
        if (!trigger_rc || trigger_errno != EIO) {
            fprintf(stderr, "expected injected EIO but trigger did not return EIO\n");
            return 1;
        }
        puts("EXPECTED_TRIGGER_EIO=PASS; NO POST_FAILURE_READS_ISSUED");
        return 0;
    }
    if (trigger_rc) { fprintf(stderr, "trigger write failed unexpectedly errno=%d\n", trigger_errno); return 1; }
    map[trigger_page] = trigger_fixture;
    if (verify_all(fd, pages, map, fixture, buf)) return 1;
    close(fd); free(map); free(fixture); free(buf);
    return 0;
}
