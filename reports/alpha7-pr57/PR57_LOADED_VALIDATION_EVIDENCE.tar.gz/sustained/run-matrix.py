#!/usr/bin/env python3
import json,subprocess,sys,time
from pathlib import Path
E=Path('/root/swapz-pr57-validation/evidence/sustained')
runner=E/'run-sustained-trial.py'
rows=[]
def execute(qd,candidate,reps,read_pct=20):
 for rep in reps:
  cmd=['python3',str(runner),'--candidate',candidate,'--rep',str(rep),'--qd',str(qd),'--read-pct',str(read_pct),'--warmup','10','--seconds','30']
  t=time.time()
  p=subprocess.run(cmd,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=900)
  label=f'{candidate}-qd{qd}-rp{read_pct}-r{rep}'
  rec={'candidate':candidate,'qd':qd,'read_pct':read_pct,'rep':rep,'command':cmd,'rc':p.returncode,'elapsed_wall_s':time.time()-t,'output':p.stdout,'recorded_at':time.time()}
  rows.append(rec)
  with (E/'sustained-matrix.jsonl').open('a') as f:f.write(json.dumps(rec)+'\n')
  print(json.dumps({'label':label,'rc':p.returncode,'elapsed':round(rec['elapsed_wall_s'],1),'summary':p.stdout.strip()[-1000:]},sort_keys=True),flush=True)
  if p.returncode: raise SystemExit(f'BLOCKED after failed trial {label}; see {E}/trials/{label}/trial.json')
def rounds(qd,spec,order):
 maxround=max(len(v) for v in spec.values())
 nextidx={k:0 for k in spec}
 for rnd in range(maxround):
  seq=[k for k in order if k in spec and nextidx[k]<len(spec[k])]
  shift=rnd%len(seq)
  seq=seq[shift:]+seq[:shift]
  if rnd%2:seq.reverse()
  for k in seq:
   rep=spec[k][nextidx[k]];nextidx[k]+=1;execute(qd,k,[rep])
order=['v22','alpha6','alpha7','pr57-b0','pr57-b1','pr57-b2']
rounds(1,{'v22':[3,4,5,6],'alpha6':[3,4,5],'pr57-b0':[1,2,3],'pr57-b1':[5,6,7,8],'pr57-b2':[1,2,3]},order)
rounds(8,{'v22':[1,2,3,4,5],'alpha6':[2,3,4],'alpha7':[1,2,3],'pr57-b0':[1,2,3],'pr57-b1':[4,5,6,7,8],'pr57-b2':[1,2,3]},order)
print('QD1_QD8_MIXED_MATRIX_COMPLETE',flush=True)
