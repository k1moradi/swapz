#!/usr/bin/env python3
"""Generate deterministic 4KiB pages with measured LZ4_compress_fast lengths."""
import collections, ctypes, ctypes.util, hashlib, json, random, struct
from pathlib import Path

OUT=Path('/root/swapz-pr57-validation/evidence/sustained/fixtures')
OUT.mkdir(parents=True,exist_ok=True)
libname=ctypes.util.find_library('lz4')
if not libname: raise SystemExit('liblz4 unavailable')
lz=ctypes.CDLL(libname)
lz.LZ4_versionString.restype=ctypes.c_char_p
lz.LZ4_compress_fast.argtypes=[ctypes.c_void_p,ctypes.c_void_p,ctypes.c_int,ctypes.c_int,ctypes.c_int]
lz.LZ4_compress_fast.restype=ctypes.c_int
lz.LZ4_decompress_safe.argtypes=[ctypes.c_void_p,ctypes.c_void_p,ctypes.c_int,ctypes.c_int]
lz.LZ4_decompress_safe.restype=ctypes.c_int
CAP=3568
SEED=0x57A7C0DE

def compress(page):
    src=ctypes.create_string_buffer(page)
    dst=ctypes.create_string_buffer(CAP)
    n=lz.LZ4_compress_fast(src,dst,4096,CAP,1)
    return bytes(dst.raw[:n]) if n>0 else None

def make_class(target, seed):
    if target=='raw':
        rng=random.Random(seed)
        return bytes(rng.getrandbits(8) for _ in range(4096))
    # With a pseudorandom literal prefix followed by copies of that prefix,
    # the project's LZ4 fast/acceleration-1 settings produce the target size.
    for n in range(max(1,target-40),target):
        rng=random.Random(seed ^ (n*0x9E3779B97F4A7C15 & ((1<<64)-1)))
        prefix=bytes(rng.getrandbits(8) for _ in range(n))
        page=(prefix*((4096+n-1)//n))[:4096]
        payload=compress(page)
        if payload is not None and abs(len(payload)-target)<=1:
            return page
    raise RuntimeError(f'could not hit target compressed length {target} seed={seed}')

# Exact 819 compressed / 205 raw mix, divided across the measured sizes.
classes=(['57']*205+['1032']*205+['2089']*205+['3500']*204+['raw']*205)
random.Random(SEED).shuffle(classes)
pages=[]; rows=[]
for i,label in enumerate(classes):
    target='raw' if label=='raw' else int(label)
    page=make_class(target,SEED+i*0x10001)
    payload=compress(page)
    if target=='raw':
        if payload is not None: raise RuntimeError(f'raw page {i} unexpectedly fits cap: {len(payload)}')
        actual=None
    else:
        if payload is None: raise RuntimeError(f'compressed page {i} failed compression')
        actual=len(payload)
        dec=ctypes.create_string_buffer(4096)
        src=ctypes.create_string_buffer(payload)
        if lz.LZ4_decompress_safe(src,dec,len(payload),4096)!=4096 or dec.raw[:4096]!=page:
            raise RuntimeError(f'LZ4 roundtrip failed at page {i}')
    pages.append(page)
    rows.append({'page':i,'class':label,'compressed_length':actual,'page_sha256':hashlib.sha256(page).hexdigest(),'lz4_sha256':hashlib.sha256(payload).hexdigest() if payload else None})
blob=b''.join(pages)
(OUT/'mixed-1024-pages.bin').write_bytes(blob)
class_ids={'57':0,'1032':1,'2089':2,'3500':3,'raw':4}
(OUT/'mixed-1024-class.bin').write_bytes(bytes(class_ids[x] for x in classes))
manifest={'seed':SEED,'liblz4':libname,'liblz4_version':lz.LZ4_versionString().decode(),'compressor':'LZ4_compress_fast, acceleration=1, input=4096, capacity=3568','raw_rule':'LZ4 return 0 at output capacity 3568','page_count':len(pages),'fixture_sha256':hashlib.sha256(blob).hexdigest(),'records':rows}
(OUT/'mixed-1024-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
counts=collections.Counter(r['class'] for r in rows)
lengths=collections.defaultdict(list)
for r in rows:
    if r['compressed_length'] is not None: lengths[r['class']].append(r['compressed_length'])
summary={'pages':len(pages),'class_counts':dict(counts),'compressed_length_histograms':{k:dict(collections.Counter(v)) for k,v in lengths.items()},'fixture_sha256':manifest['fixture_sha256'],'liblz4_version':manifest['liblz4_version']}
(OUT/'mixed-1024-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
# A class-specific corpus is the same page set filtered in stable manifest order.
for label in ('57','1032','2089','3500','raw'):
    selected=[pages[i] for i,row in enumerate(rows) if row['class']==label]
    path=OUT/f'class-{label}.bin'; path.write_bytes(b''.join(selected))
    print(label,len(selected),summary['compressed_length_histograms'].get(label,'raw'),hashlib.sha256(path.read_bytes()).hexdigest())
print(json.dumps(summary,sort_keys=True))
