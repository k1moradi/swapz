#!/usr/bin/env python3
import argparse, json, os, re, subprocess, sys, time
from pathlib import Path

NULL = "/dev/nullb_swapz_pr57_2e71c0c9"
STAT = Path("/sys/block/nullb_swapz_pr57_2e71c0c9/stat")
DMROOT = Path("/dev")
HELPER = "/root/swapz-pr57-validation/evidence/helpers/fault/sv3_fault_probe.ko"

def run(argv, timeout=90, input_text=None):
    t0=time.monotonic_ns()
    p=subprocess.run(argv, input=input_text, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=timeout)
    return {"argv":argv,"rc":p.returncode,"stdout":p.stdout,"stderr":p.stderr,"elapsed_ns":time.monotonic_ns()-t0}

def checked(argv, **kw):
    r=run(argv, **kw)
    if r["rc"] != 0: raise RuntimeError(f"failed {argv}: {r}")
    return r

def status(name):
    return checked(["dmsetup","status",name])["stdout"].strip()

def fields(line):
    return dict(t.split("=",1) for t in line.split() if "=" in t)

def no_mappings():
    s=checked(["dmsetup","ls","--noheadings"])["stdout"].strip()
    return not s or s == "No devices found"

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--nth",type=int,required=True)
    ap.add_argument("--bulk",type=int,choices=[0,1,2],required=True)
    ap.add_argument("--mode",type=int,choices=[0,1,2],required=True)
    ap.add_argument("--groups",type=int,default=2)
    ap.add_argument("--label",required=True)
    ap.add_argument("--run-helper",action="store_true")
    a=ap.parse_args()
    out=Path("/root/swapz-pr57-validation/evidence/faults")/a.label
    out.mkdir(parents=True,exist_ok=False)
    name="swz57f-"+a.label.lower().replace("_","-")[:40]
    uuid="SWZ57F-"+a.label.upper().replace("-","_")[:88]
    sectors=8192
    r={"label":a.label,"nth":a.nth,"bulk":a.bulk,"mode":a.mode,"groups":a.groups,"null":NULL,"name":name,"uuid":uuid,"phase":"preflight","start":time.time()}
    def save(): (out/"result.json").write_text(json.dumps(r,indent=2)+"\n")
    try:
      if not no_mappings(): raise RuntimeError("preexisting DM mappings; refusing test")
      if Path("/sys/module/sv3_fault_probe").exists(): raise RuntimeError("fault helper already loaded")
      if not STAT.exists() or Path("/sys/block/nullb_swapz_pr57_2e71c0c9/holders").iterdir().__next__() if False else False: pass
      r["stat_before"]=[int(x) for x in STAT.read_text().split()]
      r["status_before_dmesg"]=checked(["dmesg","--time-format","iso"])["stdout"][-20000:]
      table=f"0 {sectors} swapz3 {NULL} 0 64 0 2 0 0 {a.bulk} {a.nth}"
      r["table_requested"]=table; r["phase"]="create"; save()
      r["create"]=checked(["dmsetup","create",name,"--uuid",uuid,"--noudevrules","--noudevsync","--table",table])
      actual=checked(["dmsetup","table",name])["stdout"].strip(); r["table_actual"]=actual
      r["uuid_actual"]=checked(["dmsetup","info","-c","--noheadings","-o","uuid",name])["stdout"].strip()
      info=checked(["dmsetup","info","-c","--noheadings","-o","major,minor,open",name])["stdout"].strip(); r["dm_info_initial"]=info
      deadline=time.monotonic()+3
      while info.split(":")[-1] != "0" and time.monotonic()<deadline:
        time.sleep(0.1)
        info=checked(["dmsetup","info","-c","--noheadings","-o","major,minor,open",name])["stdout"].strip()
      r["dm_info_quiescent"]=info
      mm=info.split(":"); target=f"/dev/dm-{mm[1]}"; r["target_path"]=target
      if r["uuid_actual"]!=uuid or actual!=table.replace(NULL,"251:0") or mm[-1]!="0": raise RuntimeError("DM identity/table/open preflight mismatch after transient-open wait")
      r["status_pre"]=status(name); r["stat_pre"]=[int(x) for x in STAT.read_text().split()]
      r["dmesg_before"]=checked(["dmesg","--time-format","iso"])["stdout"][-10000:]
      r["phase"]="helper-load"; save()
      r["helper_insmod"]=run(["insmod",HELPER,f"target={target}",f"mode={a.mode}",f"groups={a.groups}"],timeout=100)
      # Module init is designed to return 0 even when test BIOs fail; record RC, do not assume it.
      r["helper_loaded"]=Path("/sys/module/sv3_fault_probe").exists()
      if r["helper_loaded"]: r["helper_rmmod"]=run(["rmmod","sv3_fault_probe"],timeout=30)
      r["status_post"]=status(name); r["status_fields"]=fields(r["status_post"])
      r["stat_post"]=[int(x) for x in STAT.read_text().split()]
      r["dmesg_after"]=checked(["dmesg","--time-format","iso"])["stdout"][-30000:]
      inflight=r["stat_post"][8]
      r["lower_inflight_after"]=inflight
      r["phase"]="cleanup-preflight"; save()
      if inflight != 0: raise RuntimeError("backing lower IO remains in flight; quarantine and do not remove")
      if not Path(f"/sys/block/nullb_swapz_pr57_2e71c0c9/holders").exists(): raise RuntimeError("owned backing disappeared")
      holders=list(Path("/sys/block/nullb_swapz_pr57_2e71c0c9/holders").iterdir())
      if len(holders)>1: raise RuntimeError(f"unexpected backing holders {holders}")
      if r["helper_loaded"] and r.get("helper_rmmod",{}).get("rc")!=0: raise RuntimeError("test helper failed to unload")
      # ordinary remove only by the just-verified owned UUID
      r["remove"]=checked(["dmsetup","remove","--uuid",uuid],timeout=30)
      if not no_mappings(): raise RuntimeError("mapping remains after UUID removal")
      if list(Path("/sys/block/nullb_swapz_pr57_2e71c0c9/holders").iterdir()): raise RuntimeError("owned backing still held after removal")
      r["phase"]="PASS-OBSERVED-AND-CLEANED"; r["end"]=time.time(); save()
      print(json.dumps({k:r.get(k) for k in ["label","phase","helper_insmod","status_post","stat_pre","stat_post","remove"]},indent=2))
      return 0
    except Exception as e:
      r["phase"]="QUARANTINED_OR_FAILED"; r["error"]=repr(e); r["end"]=time.time(); save()
      print(f"PRESERVED: {e}",file=sys.stderr)
      print(json.dumps({k:r.get(k) for k in ["label","phase","error","status_post","stat_post"]},indent=2),file=sys.stderr)
      return 1
if __name__=="__main__": sys.exit(main())
