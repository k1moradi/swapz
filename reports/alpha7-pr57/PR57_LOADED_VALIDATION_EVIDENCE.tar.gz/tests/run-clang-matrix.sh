#!/usr/bin/env bash
set -euo pipefail
SRC=/root/swapz-pr57-validation/pr57
OUT=/root/swapz-pr57-validation/evidence/tests/clang
cd "$SRC"
for opt in 0 2; do
  mkdir -p "$OUT/O$opt"
  FLAGS=(-std=c11 -O$opt -g -Wall -Wextra -Werror -I kernel/extent-v3)
  build_run() { local name=$1; shift; clang "${FLAGS[@]}" "$@" -o "$OUT/O$opt/$name"; "$OUT/O$opt/$name"; }
  build_run codec tests/runtime/extent-v3-codec-test.c kernel/extent-v3/codec.c
  build_run authority tests/runtime/extent-v3-authority-test.c kernel/extent-v3/authority.c kernel/extent-v3/codec.c
  build_run snapshots tests/runtime/extent-v3-tx-snapshot-test.c kernel/extent-v3/authority.c kernel/extent-v3/codec.c
  build_run write-verify tests/runtime/extent-v3-write-verify-test.c kernel/extent-v3/engine.c kernel/extent-v3/authority.c kernel/extent-v3/codec.c
  build_run dead-segment tests/runtime/extent-v3-dead-segment-test.c kernel/extent-v3/authority.c kernel/extent-v3/codec.c
  build_run raw-discard tests/runtime/extent-v3-raw-discard-test.c kernel/extent-v3/authority.c kernel/extent-v3/codec.c
  build_run engine tests/runtime/extent-v3-engine-test.c kernel/extent-v3/engine.c kernel/extent-v3/authority.c kernel/extent-v3/codec.c
  build_run randomized-engine tests/runtime/extent-v3-randomized-engine-test.c kernel/extent-v3/engine.c kernel/extent-v3/authority.c kernel/extent-v3/codec.c
  build_run gc-forbidden tests/runtime/extent-v3-gc-forbidden-test.c kernel/extent-v3/authority.c kernel/extent-v3/codec.c
  build_run gc-cost tests/runtime/extent-v3-gc-cost-test.c kernel/extent-v3/authority.c kernel/extent-v3/codec.c
  build_run flush tests/runtime/extent-v3-flush-test.c
  build_run gc-rotation tests/runtime/extent-v3-gc-rotation-test.c kernel/extent-v3/authority.c kernel/extent-v3/codec.c
  build_run gc-engine-rotation tests/runtime/extent-v3-gc-engine-rotation-test.c kernel/extent-v3/engine.c kernel/extent-v3/authority.c kernel/extent-v3/codec.c
  build_run bulk-io tests/runtime/extent-v3-bulk-io-test.c kernel/extent-v3/engine.c kernel/extent-v3/authority.c kernel/extent-v3/codec.c
done
printf "CLANG_MATRIX_PASS O0=14 O2=14\\n"
